package is.hi.hbv201g.styring;

import is.hi.hbv201g.vidmot.AdalTorg;
import is.hi.hbv201g.vidmot.AdalTorg.AdgerdTag;
import is.hi.hbv201g.vidmot.SkodaLag;
import is.hi.hbv201g.vinnsla.TonlistarKatalogur;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;


 // @author Ebba Þóra Hvannberg ebba@hi.is og Bjarki Hreinn Viðarsson bhv2@hi.is
 
public class StyringListi implements ListSelectionListener{
    
    private AdalTorg adalGluggi;
    TonlistarKatalogur StyringKatalog;
    
 
    public StyringListi (AdalTorg gluggi) {
        adalGluggi = gluggi;
        StyringKatalog = new TonlistarKatalogur();
        
    }

    @Override
    public void valueChanged (ListSelectionEvent evt) {
        // Náum í selectionModelið 
         ListSelectionModel lsm = (ListSelectionModel)evt.getSource();
         
         // Indexinn í listanum. 
         int index = lsm.getMinSelectionIndex();    
         
         // Indexinn prentaður út 
         System.out.println ("Index er "+index);
         
         AdgerdTag a = adalGluggi.getAdgerd();
         switch (a) {
             case SKODA:
            // Sýnum gögnin á bak við lagið
             umLag(index);
             break;
             case EYDA:
           // Spyrjum notanda hvort hann vilji eyða lagi
             eydaLagi(index);
         }   
         adalGluggi.setAdgerd(AdgerdTag.SKODA);
    }
    
     // Héðan fáum við upplýsingar um lag
    private void umLag(int lag) {
        // Búa til dialog til að birta upplýsingar
        SkodaLag umLag = new SkodaLag (adalGluggi, true);
       
     
        String titill = StyringKatalog.getLagaListi().get(lag).getTitill();
       
        String flytjandi = StyringKatalog.getLagaListi().get(lag).getFlytjandi();
        
        String yfirflokkur = StyringKatalog.getLagaListi().get(lag).getFlokkur().getHeiti();

        String undirflokkur = StyringKatalog.getLagaListi().get(lag).getUndirflokkur().getHeiti();
        
        System.out.println ("Lagið er "+titill);
        System.out.println ("Flytjandi er "+flytjandi);
        System.out.println ("Yfirflokkur er "+yfirflokkur);
        System.out.println ("Undirflokkur er "+undirflokkur);
        
        umLag.setjaGogn(titill,flytjandi,yfirflokkur,undirflokkur);
        
        // Birta dialog 
        umLag.setVisible(true);

    }
    // Aðferð til að eyða lagi af lista
    private void eydaLagi(int lag) {
        
          if (lag == -1)
              return;
          String s = adalGluggi.getLlisti().getLag(lag);
          if (JOptionPane.showConfirmDialog(adalGluggi, "Viltu eyða laginu? "+s, "Eyða lagi", JOptionPane.YES_NO_OPTION)==0)
             adalGluggi.getLlisti().eydaLagi(lag);
          TonlistarKatalogur.lagaListi.remove(lag);
    }
}

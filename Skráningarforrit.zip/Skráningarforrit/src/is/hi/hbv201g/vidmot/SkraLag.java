package is.hi.hbv201g.vidmot;

import is.hi.hbv201g.vinnsla.LagaListiModel;
import is.hi.hbv201g.vinnsla.TonlistarKatalogur;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

/**
 * Samtalsgluggi til að skrá lag
 * @author Ebba Þóra Hvannberg, ebba@hi.is og Bjarki Hreinn Viðarsson, bhv2@hi.is
 */
public class SkraLag extends javax.swing.JDialog {
    
    // segir til um hvort notandi hefur staðfest samtalsgluggann eða hætt við
    private boolean ok=false; 
    // Strengjafylki fyrir Comboboxin 
    private final String[]  yfirFlokkar = { "Jazz", "Jazz Fusion", "Metal", "Electronic", "Techno", "Rock","Noise"};
    private final String[]  undirFlokkar = { "Cool Jazz", "Orchestral", "Electronic", "Extreme Metal","Alternative Trash Metal", 
                                             "8-bit","Drum And Bass","Industrial","Alternative", "Japanese Noise"};
    
    // Tilviksbreytur fyrir yfir- og undirflokka
    private String yfirflokkur = " ";
    private String undirflokkur = " ";
    /**
     * Smiður fyrir SkraLagDialog
     *@param parent - glugginn sem kallar á samtalsgluggann 
     * @param modal - ef satt þá verður notandi að ljúka samtalinu áður en 
     * annað er gert 
     */
    public SkraLag(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        frumstillaGögn();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jUndirFlokkur = new javax.swing.JLabel();
        jOK = new javax.swing.JButton();
        jYfirflokkur = new javax.swing.JLabel();
        jFlytjandi = new javax.swing.JLabel();
        jTitill = new javax.swing.JLabel();
        jTitill2 = new javax.swing.JTextField();
        jFlytjandi2 = new javax.swing.JTextField();
        jYfirflokkarCombo = new javax.swing.JComboBox<>();
        jUndirflokkurCombo = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(204, 102, 0));

        jPanel1.setBackground(new java.awt.Color(204, 102, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 51, 0), 3));

        jUndirFlokkur.setText("  Undirflokkur");
        jUndirFlokkur.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jOK.setText("OK");
        jOK.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOKActionPerformed(evt);
            }
        });

        jYfirflokkur.setText("  Yfirflokkur");
        jYfirflokkur.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jFlytjandi.setText("  Flytjandi");
        jFlytjandi.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jTitill.setText("  Titill lags");
        jTitill.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jTitill2.setText("Sláðu inn titil lags");
        jTitill2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTitill2ActionPerformed(evt);
            }
        });

        jFlytjandi2.setText("Sláðu inn flytjanda lags");

        jYfirflokkarCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jYfirflokkarCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jYfirflokkarComboActionPerformed(evt);
            }
        });

        jUndirflokkurCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jUndirflokkurCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jUndirflokkurComboActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jFlytjandi, javax.swing.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE)
                            .addComponent(jTitill, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTitill2)
                            .addComponent(jFlytjandi2)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(105, 105, 105)
                                .addComponent(jYfirflokkur, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(90, 90, 90)
                                .addComponent(jYfirflokkarCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 23, Short.MAX_VALUE)
                                .addComponent(jUndirFlokkur, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jOK, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jUndirflokkurCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(1, 1, 1)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTitill, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTitill2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jFlytjandi, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jFlytjandi2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jUndirFlokkur, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jOK, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jYfirflokkur, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jYfirflokkarCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jUndirflokkurCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(138, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 // Handler fyrir jYfirflokkarCombo
    private void jYfirflokkarComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jYfirflokkarComboActionPerformed
        // Frá hvaða hlut kom atburðurinn
        JComboBox cb = (JComboBox)evt.getSource();
        // Hvaða yfirflokkur var valinn
        yfirflokkur = (String)cb.getSelectedItem();
    }//GEN-LAST:event_jYfirflokkarComboActionPerformed

    private void jTitill2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTitill2ActionPerformed

    }//GEN-LAST:event_jTitill2ActionPerformed
    // Hér skráum við nýtt lag þegar ýtt er á ok hnappinn
    private void jOKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jOKActionPerformed
        TonlistarKatalogur.skraLag(jTitill2.getText(),jFlytjandi2.getText(),yfirflokkur,undirflokkur);

        ok = true;
        lokaGlugga();
    }//GEN-LAST:event_jOKActionPerformed
   // Handler fyrir jUndirflokkurCombo
    private void jUndirflokkurComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jUndirflokkurComboActionPerformed
        // Frá hvaða hlut kom atburðurinn
        JComboBox cb = (JComboBox)evt.getSource();
        // Hvaða undirflokkur var valinn
        undirflokkur = (String)cb.getSelectedItem();

    }//GEN-LAST:event_jUndirflokkurComboActionPerformed

private void frumstillaGögn() {
          
        /**
         * búum til módel (þ.e. gögnin) fyrir combobox
         * DefaultComboBoxModel er klasi sem erfir frá ComboBoxModel interface
         * <> merkir að gögnin eru af óþekktu tagi (type)
         **/
        DefaultComboBoxModel mittModel;
        mittModel = new javax.swing.DefaultComboBoxModel<>(yfirFlokkar);
        jYfirflokkarCombo.setModel(mittModel);
        
        DefaultComboBoxModel mittModel2;
        mittModel2 = new javax.swing.DefaultComboBoxModel<>(undirFlokkar);
        jUndirflokkurCombo.setModel(mittModel2);

    }/**
 * Lokar glugga og eyðir gluggaviðföngum
 */
    private void lokaGlugga() {
        setVisible(false);
        dispose();
    }
    // Nær í titil lags
    public String getLag() {
        return jTitill2.getText();
    }
     /**
    * Skilar satt ef notandi hefur ýtt á ok hnapp í samtalsglugga
    * @return satt ef notandi hefur ýtt á ok en annars ósatt
    */
    public boolean isOk() {
        return ok;
    }
    
    /**
     * Setur gildi á ok hnapp í samræmi við val í samtalsglugga 
     * @param b true/false
     */
    public void setOk(boolean b) {
        ok = b;
    }
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SkraLag dialog = new SkraLag(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jFlytjandi;
    private javax.swing.JTextField jFlytjandi2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton jOK;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jTitill;
    private javax.swing.JTextField jTitill2;
    private javax.swing.JLabel jUndirFlokkur;
    private javax.swing.JComboBox<String> jUndirflokkurCombo;
    private javax.swing.JComboBox<String> jYfirflokkarCombo;
    private javax.swing.JLabel jYfirflokkur;
    // End of variables declaration//GEN-END:variables
}

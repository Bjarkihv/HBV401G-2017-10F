package is.hi.hbv201g.vidmot;

/**
 * Samtalsgluggi til að skoða lög
 * @author Ebba Þóra Hvannberg, ebba@hi.is og Bjarki Hreinn Viðarsson, bhv2@hi.is
 */
public class SkodaLag extends javax.swing.JDialog {
    
    // segir til um hvort notandi hefur staðfest samtalsgluggann eða hætt við
    private boolean ok=false; 

    public SkodaLag(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jUndirflokkur2 = new javax.swing.JLabel();
        jUndirFlokkur = new javax.swing.JLabel();
        jOK = new javax.swing.JButton();
        jYfirflokkur2 = new javax.swing.JLabel();
        jYfirflokkur = new javax.swing.JLabel();
        jFlytjandi = new javax.swing.JLabel();
        jFlytjandi2 = new javax.swing.JLabel();
        jTitill2 = new javax.swing.JLabel();
        jTitill = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(204, 102, 0));

        jPanel1.setBackground(new java.awt.Color(204, 102, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 51, 0), 3));

        jUndirflokkur2.setBackground(new java.awt.Color(255, 255, 255));
        jUndirflokkur2.setText("Hér kemur undirflokkurinn");
        jUndirflokkur2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jUndirflokkur2.setOpaque(true);

        jUndirFlokkur.setText("  Undirflokkur");
        jUndirFlokkur.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jOK.setText("OK");
        jOK.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOKActionPerformed(evt);
            }
        });

        jYfirflokkur2.setBackground(new java.awt.Color(255, 255, 255));
        jYfirflokkur2.setText("Hér kemur yfirflokkurinn");
        jYfirflokkur2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jYfirflokkur2.setOpaque(true);

        jYfirflokkur.setText("  Yfirflokkur");
        jYfirflokkur.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jFlytjandi.setText("  Flytjandi");
        jFlytjandi.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jFlytjandi2.setBackground(new java.awt.Color(255, 255, 255));
        jFlytjandi2.setText("Hér kemur flytjandinn");
        jFlytjandi2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jFlytjandi2.setOpaque(true);

        jTitill2.setBackground(new java.awt.Color(255, 255, 255));
        jTitill2.setText("Hér kemur titillinn");
        jTitill2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jTitill2.setOpaque(true);

        jTitill.setText("  Titill lags");
        jTitill.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jOK, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jUndirFlokkur, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE)
                            .addComponent(jYfirflokkur, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jFlytjandi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTitill, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jTitill2, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jFlytjandi2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jYfirflokkur2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jUndirflokkur2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jTitill2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jTitill, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jFlytjandi, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jFlytjandi2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jYfirflokkur, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jYfirflokkur2))
                        .addGap(29, 29, 29))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jUndirFlokkur, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jUndirflokkur2)))
                .addComponent(jOK, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Setja gögn í samtalsgluggann. Upplýsingar um lag
     * @param s strengur sem gögnin eru geymd í 
     */
    public void setjaGogn(String t, String f, String y, String u) {
        
        int endiKodi1 = t.indexOf("  ", 0);
        int endiKodi2 = f.indexOf("  ", 0);
        int endiKodi3 = y.indexOf("  ", 0);
        int endiKodi4 = u.indexOf("  ", 0);
        
        jTitill2.setText(t.substring(endiKodi1+1,t.length()));
        jFlytjandi2.setText(f.substring(endiKodi2+1,f.length()));
        jYfirflokkur2.setText(y.substring(endiKodi3+1,y.length()));
        jUndirflokkur2.setText(u.substring(endiKodi4+1,u.length()));
    }
    

    private void jOKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jOKActionPerformed
        ok = true; 
        lokaGlugga();
    }//GEN-LAST:event_jOKActionPerformed
/**
 * Lokar glugga og eyðir gluggaviðföngum
 */
    private void lokaGlugga() {
        setVisible(false);
        dispose();
    }

    /**
     * Nær í textann sem hefur verið sett inn í jNamskeidTitill sviðið 
     * @return 
     */
    public String getLag() {
        return jTitill2.getText();
    }
     /**
    * Skilar satt ef notandi hefur ýtt á ok hnapp í samtalsglugga
    * @return satt ef notandi hefur ýtt á ok en annars ósatt
    */
    public boolean isOk() {
        return ok;
    }
    
    /**
     * Setur gildi á ok hnapp í samræmi við val í samtalsglugga 
     * @param b true/false
     */
    public void setOk(boolean b) {
        ok = b;
    }
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SkodaLag dialog = new SkodaLag(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jFlytjandi;
    private javax.swing.JLabel jFlytjandi2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton jOK;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jTitill;
    private javax.swing.JLabel jTitill2;
    private javax.swing.JLabel jUndirFlokkur;
    private javax.swing.JLabel jUndirflokkur2;
    private javax.swing.JLabel jYfirflokkur;
    private javax.swing.JLabel jYfirflokkur2;
    // End of variables declaration//GEN-END:variables
}

package is.hi.hbv201g.vidmot;

import is.hi.hbv201g.styring.StyringListi;
import javax.swing.DefaultListModel;
import is.hi.hbv201g.vinnsla.LagaListiModel;
import is.hi.hbv201g.vinnsla.FlokkarModel;
import is.hi.hbv201g.vinnsla.TonlistarKatalogur;

/**
 *
 * @authors Ebba Þóra Hvannberg, Háskóli Íslands, ebba@hi.is
 *          Bjarki Hreinn Viðarsson, Háskóli Íslands, bhv2@hi.is
 * 
 */
public class AdalTorg extends javax.swing.JFrame {

    private final LagaListiModel Llisti; 

    public AdgerdTag getAdgerd() {
        return adgerd;
    }

    public void setAdgerd(AdgerdTag adgerd) {
        this.adgerd = adgerd;
    }
  
    public enum AdgerdTag {SKODA, EYDA};
    
    private AdgerdTag adgerd=AdgerdTag.SKODA;
    
    TonlistarKatalogur minnKatalogur;
    
    
    /**
     * Smiður fyrir AdalTorg
     */
    public AdalTorg()  {
        initComponents();
       
        // Lesum inn XML gögn með því að smíða TónlistarKatalog
        minnKatalogur = new TonlistarKatalogur();
        
        // Við notum birtaLogin fallið til að sýna að gögin 
        // hafi verið lesin rétt inn
        minnKatalogur.birtaLogin();
      
        FlokkarModel fModel = new FlokkarModel(minnKatalogur.getFlokkar());
        jFlokkar.setModel(fModel.getModel());

        /** Tengjum hlýði við listann 
         *  Það er StyringfyrirLista hluturinn sem ætlar að hlusta á hvort stök eru 
         *  valin á listanum 
        */
        jLagaListi.getSelectionModel().addListSelectionListener(new StyringListi(this));
        
        /**
         * Búum til gagnahlut forritsins sem geymir gögn úr kennsluskrá
         */
        Llisti = new LagaListiModel((DefaultListModel)jLagaListi.getModel());
    
    }
    
    private void birtaLag(int indexLag) {
        System.out.println ("lag nr. "+(indexLag+1));
        System.out.println (
                minnKatalogur.getLagaListi().get(indexLag).getTitill());
        
         System.out.println (
        minnKatalogur.getLagaListi().get(indexLag).getFlytjandi());
         
        System.out.println (
        minnKatalogur.getLagaListi().get(indexLag).getFlokkur().getHeiti());
        
        System.out.println (
        minnKatalogur.getLagaListi().get(indexLag).getUndirflokkur().getHeiti());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTolaSla = new javax.swing.JToolBar();
        jSkraLag = new javax.swing.JButton();
        jEydaNamskeidi = new javax.swing.JButton();
        jGrunnur = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jLagaListi = new javax.swing.JList<>();
        DefaultListModel listModel = new DefaultListModel();
        jLagaListi.setModel(listModel);
        jScrollPane3 = new javax.swing.JScrollPane();
        jFlokkar = new javax.swing.JTree();
        jLagaListiLabel = new javax.swing.JLabel();
        jFlokkarLabel = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Listi Sýnidæmi");
        setBackground(new java.awt.Color(204, 102, 0));

        jTolaSla.setBackground(new java.awt.Color(204, 102, 0));
        jTolaSla.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        jTolaSla.setRollover(true);

        jSkraLag.setBackground(new java.awt.Color(204, 102, 0));
        jSkraLag.setText("Bæta við lagi");
        jSkraLag.setFocusable(false);
        jSkraLag.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jSkraLag.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jSkraLag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSkraLagActionPerformed(evt);
            }
        });
        jTolaSla.add(jSkraLag);

        jEydaNamskeidi.setBackground(new java.awt.Color(204, 102, 0));
        jEydaNamskeidi.setText("Eyða lagi");
        jEydaNamskeidi.setFocusable(false);
        jEydaNamskeidi.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jEydaNamskeidi.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jEydaNamskeidi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEydaNamskeidiActionPerformed(evt);
            }
        });
        jTolaSla.add(jEydaNamskeidi);

        jGrunnur.setBackground(new java.awt.Color(153, 0, 0));

        jLagaListi.setBackground(new java.awt.Color(204, 102, 0));
        jLagaListi.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jScrollPane1.setViewportView(jLagaListi);

        jFlokkar.setBackground(new java.awt.Color(204, 102, 0));
        jFlokkar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jScrollPane3.setViewportView(jFlokkar);

        jLagaListiLabel.setBackground(new java.awt.Color(204, 102, 0));
        jLagaListiLabel.setFont(new java.awt.Font("Leelawadee UI Semilight", 1, 18)); // NOI18N
        jLagaListiLabel.setText(" Lagalisti");
        jLagaListiLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        jLagaListiLabel.setOpaque(true);

        jFlokkarLabel.setBackground(new java.awt.Color(204, 102, 0));
        jFlokkarLabel.setFont(new java.awt.Font("Leelawadee UI Semilight", 1, 18)); // NOI18N
        jFlokkarLabel.setText(" Flokkar");
        jFlokkarLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        jFlokkarLabel.setOpaque(true);

        javax.swing.GroupLayout jGrunnurLayout = new javax.swing.GroupLayout(jGrunnur);
        jGrunnur.setLayout(jGrunnurLayout);
        jGrunnurLayout.setHorizontalGroup(
            jGrunnurLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jGrunnurLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 308, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jGrunnurLayout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jFlokkarLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLagaListiLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(121, 121, 121))
        );
        jGrunnurLayout.setVerticalGroup(
            jGrunnurLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jGrunnurLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jGrunnurLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLagaListiLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jFlokkarLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jGrunnurLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 265, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jGrunnur, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jTolaSla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addComponent(jTolaSla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jGrunnur, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Handler fyrir bæta við lagi hnappinn. Býr til dialog sem skráir upplýsingar
     * um lagið
     * @param evt 
     */
    private void jSkraLagActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSkraLagActionPerformed
 
      // Búa til dialog til að skrá lag  
        SkraLag skraDialog = new SkraLag (this, true);
    
      // Birta dialog 
        skraDialog.setVisible(true);
        
      // Náum í gögnin úr dialog 
        String nyttLag = skraDialog.getLag();
        
      // Bætum laginu við listann ef notandi staðfestir 
      if (skraDialog.isOk())
          ((DefaultListModel)jLagaListi.getModel()).addElement(nyttLag);
         
    }//GEN-LAST:event_jSkraLagActionPerformed

    private void jEydaNamskeidiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEydaNamskeidiActionPerformed
        // Aðgerðin er Eyda
        setAdgerd(AdgerdTag.EYDA);
        System.out.println ("Vil eyða lagi");
    }//GEN-LAST:event_jEydaNamskeidiActionPerformed
   
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdalTorg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdalTorg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdalTorg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdalTorg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdalTorg().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jEydaNamskeidi;
    private javax.swing.JTree jFlokkar;
    private javax.swing.JLabel jFlokkarLabel;
    private javax.swing.JPanel jGrunnur;
    private javax.swing.JList<String> jLagaListi;
    private javax.swing.JLabel jLagaListiLabel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton jSkraLag;
    private javax.swing.JToolBar jTolaSla;
    // End of variables declaration//GEN-END:variables

    /**
     * Skilar hiKennsluskra tilviksbreytu 
     * @return the hiKennsluskra
     */
    public LagaListiModel getLlisti() {
        return Llisti;
    }
}

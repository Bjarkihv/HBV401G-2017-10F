package is.hi.hbv201g.vinnsla;

import javax.swing.DefaultListModel;
import is.hi.hbv201g.vinnsla.TonlistarKatalogur;
import java.util.ArrayList;
import is.hi.hbv201g.gogn.*;
/**
 * Geymir gögn fyrir lagalista
 * Listi af lögum
 * @author Ebba Þóra Hvannberg ebba@hi.is og Bjarki Hreinn Viðarsson bhv2@hi.is
 */
public class LagaListiModel {
    DefaultListModel log;
    TonlistarKatalogur minnKatalogur;
    
    
    public LagaListiModel (DefaultListModel log) {
        // hluturinn sem geymir gögnin, þ.e. listann af lögunum. 
        this.log = log;
        minnKatalogur = new TonlistarKatalogur();
        
        // Bætum gögnunum við 
        for(int i = 0; i < 10 ; i++){
        log.addElement(minnKatalogur.getLagaListi().get(i).getTitill());
        }
 
        
    }
    // Aðferð til að birta upplýsingar um lag sem lesið hefur verið inn
    private void birtaLag(int indexLag) {
        System.out.println ("lag nr. "+(indexLag+1));
        System.out.println (
                minnKatalogur.getLagaListi().get(indexLag).getTitill());
        
         System.out.println (
        minnKatalogur.getLagaListi().get(indexLag).getFlytjandi());
         
        System.out.println (
        minnKatalogur.getLagaListi().get(indexLag).getFlokkur().getHeiti());
        
        System.out.println (
        minnKatalogur.getLagaListi().get(indexLag).getUndirflokkur().getHeiti());
    }
    // Aðferð til að eyða lagi af lista
    public void eydaLagi(int n) {
        if (n != -1)
            log.remove(n);
    }
    
    
    public String getLag (int index) {
        if(index != -1)
         return (String)log.get(index);
        else
         return "";
    }
    
}

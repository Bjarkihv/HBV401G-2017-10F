/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package is.hi.hbv201g.vinnsla;

import is.hi.hbv201g.gogn.LagaListi;
import java.util.ArrayList;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;

/**
 *
 * @author Ebba Þóra Hvannberg ebba@hi.is
 */
public class FlokkarModel {
    private DefaultTreeModel model;
    
    public FlokkarModel(ArrayList<LagaListi.YFl> flokkar) {
        TreeNode r = smidaFlokkaTre(flokkar);
        model = new DefaultTreeModel(r);
    } 

    private TreeNode smidaFlokkaTre(ArrayList<LagaListi.YFl> flokkar) {
          DefaultMutableTreeNode rot;
          DefaultMutableTreeNode barn;
          
          rot = new DefaultMutableTreeNode();
          
          for (LagaListi.YFl y: flokkar ) {
              barn = new DefaultMutableTreeNode (y.getFl().getHeiti());
              rot.add(barn);
              ArrayList<LagaListi.YFl.UFl> uFlokkar = (ArrayList<LagaListi.YFl.UFl>)y.getUFl();
              for (LagaListi.YFl.UFl u: uFlokkar) {
                  DefaultMutableTreeNode barnaBarn = new DefaultMutableTreeNode(u.getFl().getHeiti());
                  barn.add(barnaBarn);
              }
          }
          return rot;
    }
    
    public DefaultTreeModel getModel() {
        return model;
    }
}

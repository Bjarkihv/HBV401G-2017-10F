package is.hi.hbv201g.vinnsla;

import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import is.hi.hbv201g.gogn.*;
import java.net.URL;
import java.util.ArrayList;
/**
 *
 * @author Ebba Þóra Hvannberg, Háskóli Íslands, ebba@hi.is
 */
public class TonlistarKatalogur {
    
    public static ArrayList <LagaListi.Lag> lagaListi;
    private LagaListi llisti;
    
    private ArrayList <LagaListi.YFl> flokkar;
    
    public TonlistarKatalogur (){ 
        File XMLfile=null;
        try{
            JAXBContext jaxbContext = JAXBContext.newInstance(LagaListi.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            
            URL urlFyrirTonlist = this.getClass().getResource("TonlistarGogn.xml");
            try {
                XMLfile = new File(urlFyrirTonlist.getPath());
            } catch(NullPointerException e) {
                System.out.println ("Skrá með XML gögnum fannst ekki");
                e.printStackTrace();
            }
     
         llisti = (LagaListi) jaxbUnmarshaller.unmarshal(XMLfile);
         lagaListi = (ArrayList<LagaListi.Lag>)llisti.getLag(); 
         
         flokkar = (ArrayList<LagaListi.YFl>)llisti.getYFl();
                     
        } catch (JAXBException e) {
            e.printStackTrace();
            System.out.println ("Villa í lestri á XML skrá");
        }
             
       } 
    
    public ArrayList<LagaListi.Lag> getLagaListi () {
           return lagaListi;  
}
    
    public ArrayList<LagaListi.YFl>getFlokkar() {
        return (ArrayList<LagaListi.YFl>)llisti.getYFl();
    }
    
    /**
     * Aðferð sem prentar út titil lagsins á console. 
     * Getur verið gagnlegt til að sjá hvort gögnin hafa komist inn 
       *  */
    public void birtaLogin() {
        
         System.out.println ("lengdin er "+ lagaListi.size());
         for (int i=0; i<lagaListi.size() ;i++) {
            System.out.println ("lagið er "+lagaListi.get(i).getTitill());
        }
    }
    
    /**
     * Aðferð sem prentar út heiti flokka á console. 
     * Getur verið gagnlegt til að sjá hvort gögnin hafa komist inn 
       *  */
    public void birtaFlokka() {
        System.out.println ("lengdin er "+ flokkar.size());
        for (int i=0; i<flokkar.size() ;i++) {
            System.out.println ("flokkurinn er "+flokkar.get(i).getFl().getHeiti());
        }
    }
    /**
     * Eyðir lagi í lagalistanum 
     * @param indexLags - 
     */
    public void eydaLagi (int indexLags) {
        lagaListi.remove(indexLags);
    }
    //Bætum við nýju lagi út frá gefnum upplýsingum
    public static void skraLag(String t, String f, String y, String u) {
        LagaListi.Lag mittLag = new LagaListi.Lag ();
        TFlokkur fl = new TFlokkur();
        UFlokkur un = new UFlokkur();
        
        fl.setHeiti(y);
        un.setHeiti(u);
        
        mittLag.setTitill(t); 
        mittLag.setFlytjandi(f); 
        mittLag.setFlokkur(fl);
        mittLag.setUndirflokkur(un);
        
        TonlistarKatalogur.lagaListi.add(mittLag);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import FSE.model.Flight;
/**
 *
 * @author indri
 */
public abstract class  allDataSQLController {
    public abstract Flight[] getFlights(int flightNumber, String departureLocation, String departureDestination,String departureDate,String arrivalDate,Boolean isOneWay, int flightPrice, int seatCount, String airLine,String planeType);
}


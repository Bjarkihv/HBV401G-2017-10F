/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import FSE.model.Flight;
import FSE.model.Account;
import Controller.Account_controller;
/**
 *
 * @author indri
 */
public class allDataSQL {
    
    private boolean UpdateDB (String SQL){
       boolean wasSuccess = false;
       Connection conn = null;
       Statement stmt;
       try {
           // db parameters
        String url = "jdbc:sqlite:../FlightSearchEngine/src/database/flightDatabase.db";
           // create a connection to the database
           conn = DriverManager.getConnection(url);
           conn.setAutoCommit(false);
           stmt = conn.createStatement();
           stmt.executeUpdate(SQL);
           
           stmt.close();
           conn.commit();
           conn.close();
           wasSuccess = true;
           System.out.println("Uppfærsla á gagnagrunni hefur tekist og tening við gagnagrunn hefur tekist.");
           
       } catch (SQLException e) {
           System.out.println(e.getMessage());
       } finally {
           try {
               if (conn != null) {
                   conn.close();
               }
           } catch (SQLException ex) {
               System.out.println(ex.getMessage());
           }
       }
       return wasSuccess;
   }/*
    public boolean addIntoAccount(NewUser user){
        
             
    
               return UpdateDB(sql);
    }*/
    
    
    /*
    String sql = "SELECT FlightID, departureLocation,"
        		+ "departureDestination, departureTime,departureDate,arrivalDate,arrivalTime"
                + ",flightPrice,seatCount,isOneWay,airLine FROM FlightDB";
    */
    //public Flight[] getFlights(int flightNumber, String departureLocation, String departureDestination,String departureDate,String departureTime, String arrivalTime,Boolean isOneWay, int flightPrice, int seatCount, String airLine)
    public Flight[] getFlights(int flightNumber, String departureLocation, String departureDestination,String departureDate,String arrivalDate,Boolean isOneWay, int flightPrice, int seatCount, String airLine,String planeType)
    {
        Connection conn;
        Statement stmt;
        Flight[] out;
        out = null;
        
        try{
            
           String url = "jdbc:sqlite:../FlightSearchEngine/src/database/flightDatabase.db";
           // create a connection to the database
            conn = DriverManager.getConnection(url);
            stmt = conn.createStatement();
             String sql = "SELECT FlightID, departureLocation,"
        		+ "departureDestination, departureDate,arrivalDate"
                + ",flightPrice,seatCount,isOneWay,airLine,planeType FROM FlightDB";
             ResultSet rs = stmt.executeQuery(sql);
             
             Flight[] flights = new Flight[15];
             int counter = 0;
             
            while(rs.next()){
                 int flightNr = rs.getInt("flightID");
                 String departLoc = rs.getString("departureLocation");
                 String departDes = rs.getString("departureDestination");
                 
                 String departDate = rs.getString("departureDate");
                 String arrivDate = rs.getString("arrivalDate");
                 
                 int flightCost = rs.getInt("flightPrice");
                 int seatsLeft = rs.getInt("seatCount");
                 Boolean isDirect = rs.getBoolean("isOneWay");
                 String airLineName = rs.getString("airLine");
                 String planeTypeName = rs.getString("planeType");
                 
                 
                 //DateFormatter dateFormatter = new DateFormatter();
                 //Date dateDepartDate = dateFormatter.stringToDate(departDate);
                 //Date dateArrivDate = dateFormatter.stringToDate(arrivDate);
                 
                 Flight flight = new Flight(flightNr,departLoc, departDes,departDate,arrivDate,isDirect,flightCost,seatsLeft,airLineName,planeTypeName);
                 //Flight flight = new Flight(departLoc, departDes,dateDepartDate,departTime,dateArrivDate,flightCost,seatsLeft,airLineName);
                 flights[counter] = flight;
                 counter++;
                 
                 if(counter == flights.length) {
                     Flight[] temp = new Flight[counter+1];
                     for(int i=0;i<counter;i++) temp[i]=flights[i];
                     flights=temp;
                 }
                         
                 
                 
             }
            out = new Flight[counter];
            for(int i = 0;i<counter;i++) out[i]=flights[i];
            rs.close();
            stmt.close();
            conn.commit();
            conn.close();
        }catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return out;
        }
    
    public boolean addAccount(Account acc){
        
        String sql = "INSERT INTO AccountInfo(accountName, accountPW)"
                +"VALUES ('" + acc.getUsername() + "','" + acc.getPassword() + "');";
        
        
        return UpdateDB(sql);
    }
    public Account findUserByUsername(String username){
        //String sql = "INSERT INTO AccountInfo(accountName, accountPW)"
         // +"VALUES ('" + acc.getUsername() + "','" + acc.getPassword() + "');";
        Connection conn;
        Statement stmt;
        Account findUsername = null;
        //findUsername = null;
         
        try {
            String url = "jdbc:sqlite:../FlightSearchEngine/src/database/flightDatabase.db";
           // create a connection to the database
            conn = DriverManager.getConnection(url);
            stmt = conn.createStatement();
            
             String sql = "SELECT AccountName, AccountPW FROM AccountInfo WHERE AccountName LIKE ('" + username + "');";
             ResultSet rs = stmt.executeQuery(sql);
             
             //Account confirmer = new Account;
           //  int counter = 0;
             
            while(rs.next()){
                 
                 String usern = rs.getString("AccountName");
                 String passw = rs.getString("AccountPW");
                 
                 
                 findUsername = new Account(usern,passw);
                 //Flight flight = new Flight(departLoc, departDes,dateDepartDate,departTime,dateArrivDate,flightCost,seatsLeft,airLineName);
            }
            
            rs.close();
            stmt.close();
            conn.commit();
            conn.close();
            
         }catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return findUsername;
        }
}
        
        
        
        
     



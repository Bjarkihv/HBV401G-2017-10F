/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import FSE.model.Account;
import database.allDataSQL;

/**
 *
 * @author Notandi
 */
public class Account_controller {
    allDataSQL db;
    Account username;
    Account password;
    
        public Account_controller(){
            db = new allDataSQL();
        }
    public boolean addAccount(Account acc){
        
        return db.addAccount(acc);
        
    }
    public Account findByUsername(String username){
        return db.findUserByUsername(username);
    }
    
}
/*public class Flight_controller {
    allDataSQL db;
    
    
        public Flight_controller(){
        db = new allDataSQL();
    }
    public Flight[] getFlights(int flightNr, String departureLocation, String departureDestination,String departureDate, String arrivalTime,Boolean isDirect, int flightCost, int seatCount, String airLine, String planeType) {
        return db.getFlights(flightNr,departureLocation, departureDestination, departureDate, arrivalTime,isDirect, flightCost, seatCount, airLine, planeType); 
        
        }
    public Flight[] getFlightsByPriceRange(int start, int finish) {
       Flight[] flights= db.getFlights(0,"","","","",true,0,0,"","");
       Flight[] flights1 = new Flight[flights.length];
       int j = 0;
       for(int i = 0;i<flights.length;i++){
           if(flights[i].getFlightPrice() > start && flights[i].getFlightPrice() < finish){
               flights1[j] = flights[i];
               j++;
           }
       }
       
        return flights1;
    }
}
*/
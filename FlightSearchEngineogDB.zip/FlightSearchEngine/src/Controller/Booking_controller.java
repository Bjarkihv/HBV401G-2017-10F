/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import FSE.model.Booking;
import FSE.view.bookingWindow;
import static FSE.view.bookingWindow.noOfTicketsSpinner;
/**
 *
 * @author Notandi
 */
public class Booking_controller {
    
    public static double changeTotalPrice(Booking booking){
        int tickets = booking.getNoOfTickets();
        int luggagewt = booking.getLuggageWeight();
        double ticPrice = booking.getFlightPrice();
        
        
        double total = ((ticPrice * tickets) + (changeLug(booking.getCurrency(), luggagewt, "kg") * tickets));
       
        return total;
        
    }
    
    public static double changeCurrency(String cur, String prevCur, double newPrice){
      
      
        if(cur.equals("ISK")){ 
           newPrice = changeCurToISK(prevCur, newPrice);
        }
        else if(cur.equals("USD")){ 
            newPrice = changeCurToISK(prevCur, newPrice);
            newPrice = (newPrice / 112.73);
        }
        else if(cur.equals("DKK")){ 
            newPrice = changeCurToISK(prevCur, newPrice);
            newPrice = (newPrice / 16.21);
        }
        else if(cur.equals("GBP")){ 
            newPrice = changeCurToISK(prevCur, newPrice);
            newPrice = (newPrice / 141.17);
        }
        else if(cur.equals("EUR")){ 
            newPrice = changeCurToISK(prevCur, newPrice);
            newPrice = (newPrice / 120.54);
        }
        else if(cur.equals("NOK")){ 
            newPrice = changeCurToISK(prevCur, newPrice);
            newPrice = (newPrice / 13.13);
        }
        else if(cur.equals("SEK")){ 
            newPrice = changeCurToISK(prevCur, newPrice);
            newPrice = (newPrice / 12.61);
        }
        else if(cur.equals("CHF")){ 
            newPrice = changeCurToISK(prevCur, newPrice);
            newPrice = (newPrice / 112.69);
        }
        else if(cur.equals("JPY")){ 
            newPrice = changeCurToISK(prevCur, newPrice);
            newPrice = (newPrice / 1.01);
            
        }
        
       return newPrice;
    
    }
    public static double changeCurToISK(String cur, double currentTotal){
        
        if(cur.equals("USD")) currentTotal = (currentTotal * 112.73);
        if(cur.equals("DKK")) currentTotal = (currentTotal * 16.21);
        if(cur.equals("GBP")) currentTotal = (currentTotal * 141.17);
        if(cur.equals("EUR")) currentTotal = (currentTotal * 120.54);
        if(cur.equals("NOK")) currentTotal = (currentTotal * 13.13);
        if(cur.equals("SEK")) currentTotal = (currentTotal * 12.61);
        if(cur.equals("CHF")) currentTotal = (currentTotal * 112.69);
        if(cur.equals("JPY")) currentTotal = (currentTotal * 1.01);
        
        return currentTotal;
    }
    
    
    public static double changeLug(String cur, double lug, String mes){
       double mult = 227.275;
       
        if(cur.equals("ISK")){ 
           if(mes.equals("kg"))
              lug = lug * 500;
           else
              lug = lug * mult;
        }
        else if(cur.equals("USD")){ 
            if(mes.equals("kg"))
               lug = (lug * 500) / 112.73;
            else
               lug = (lug * mult) / 112.73;
            
        }
        else if(cur.equals("DKK")){ 
            if(mes.equals("kg"))
                lug = (lug * 500) / 16.21;
            else
                lug = (lug * mult) / 16.21;
        }
        else if(cur.equals("GBP")){ 
            if(mes.equals("kg"))
                lug = (lug * 500) / 141.17;
            else
                lug = (lug * mult) / 141.17;
        }
        else if(cur.equals("EUR")){ 
            if(mes.equals("kg"))
                lug = (lug * 500) / 120.54;
            else
                lug = (lug * mult) / 120.54;
        }
        else if(cur.equals("NOK")){ 
            if(mes.equals("kg"))
                lug = (lug * 500) / 13.13;
            else
                lug = (lug * mult) / 13.13;
        }
        else if(cur.equals("SEK")){ 
            if(mes.equals("kg"))
                lug = (lug * 500) / 12.61;
            else
                lug = (lug * mult) / 12.61;
        }
        else if(cur.equals("CHF")){ 
            if(mes.equals("kg"))
                lug = (lug * 500) / 112.69;
            else
                lug = (lug * mult) / 112.69;
        }
        else if(cur.equals("JPY")){ 
            if(mes.equals("kg"))
                lug = (lug * 500) / 1.01;
            else
                lug = (lug * mult) / 1.01;
            
        }
        
       return lug;
    
    }

    
    
}

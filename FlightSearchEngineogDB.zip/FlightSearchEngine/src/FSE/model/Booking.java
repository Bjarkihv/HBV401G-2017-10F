/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FSE.model;

/**
 *
 * @author Notandi
 */
public class Booking {
    int flightNo;
    String userName;
    int noOfTickets;
    int[] seats;
    int luggageWeight;
    double luggagePrice;
    double flightPrice;
    double totalPrice;
    String currency = "ISK";
    String previousCurrency = "ISK";
    
    public Booking(int fn, String un, int noT, int[] sts, double fp, int lw, double lp, double tp, String cur) {
        flightNo = fn;
        userName = un;
        noOfTickets = noT;
        seats = sts;
        flightPrice = fp;
        luggageWeight = lw;
        luggagePrice = lp;
        totalPrice = tp;
        currency = cur;
    } 
    
    
    public int getFlightNo() {
        return flightNo;
    }
    public void setFlightNo(int a) {
        flightNo = a;
    }
    
    public String getUserName() {
        return userName;
    }
    public void setUserName(String a) {
        userName = a;
    }
    
    public int getNoOfTickets() {
        return noOfTickets;
    }
    public void setNoOfTickets(int a) {
        noOfTickets = a;
    }
    
    public int[] getSeats() {
        return seats;
    }
    public void setSeats(int[] a) {
        seats = a;
    }
    
    public int getLuggageWeight() {
        return luggageWeight;
    }
    public void setLuggageWeight(int a) {
        luggageWeight = a;
    }
    public double getLuggagePrice() {
        return luggagePrice;
    }
    public void setLuggagePrice(double a) {
        luggagePrice = a;
    }
    
    public double getTotalPrice() {
        return totalPrice;
    }
    public void setTotalPrice(double a) {
        totalPrice = a;
    }
    public double getFlightPrice() {
        return flightPrice;
    }
    public void setFlightPrice(double a) {
        flightPrice = a;
    }
    
    public String getCurrency() {
        return currency;
    }
    
    public void setCurrency(String s) {
        currency = s;
    }
    public void setFlightNo(String a) {
        currency = a;
    }
    
     public String getPreviousCurrency() {
        return previousCurrency;
    }
    
    public void setPreviousCurrency(String s) {
        previousCurrency = s;
    }
}


package FSE.model;
import Controller.Account_controller;


public class Account {
    private String username;
    private String password;
    
    
    public Account(String user, String passw){
        this.username = user;
        this.password = passw;
    }
    
    public void setUsername(String usn){
        this.username = usn;
    }
    public String getUsername()
    {
        return this.username;
    }
    public void setPassword(String psw){
        this.password = psw;
    }
    public String getPassword()
    {
    return this.password;
    }
    
}

/*public class Flight {
    public int flightNo;
    public String airline;
    public String departureTime;
    public String arrivalTime;
    public String departureLocation;
    public String departureDate;
    public String arrivalLocation;
    public Boolean direct;
    public int flightPrice;
    public int seatsAvailable;
    public int[] seats;
    public String plane;
    
    public Flight(int fn,String dtd, String at, String dl, String al, Boolean dir, int sa, int fp, String airl,String pl) {
        flightNo = fn;
        airline = airl;
        //departureTime = dt;
        departureDate = dtd;
        arrivalTime = at;
        departureLocation = dl;
        arrivalLocation = al;
        direct = dir;
        seatsAvailable = sa;
        plane = pl;
        flightPrice = fp;
    } */
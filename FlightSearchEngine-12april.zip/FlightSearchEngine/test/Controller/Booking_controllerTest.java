package Controller;

import FSE.model.Booking;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class Booking_controllerTest {
    //All of the functions have a booking parameter, so we initialize one here.
    private Booking booking;

    @Before
    public void setUp() {
        //Here we insert the information needed for the tests into the booking.
        
        booking = new Booking(1337, "bhv2", 3/*fjöldi miða*/, null,
                20000/*verð miða*/, 30/*þyngd farangurs*/, 0, "ISK");
    }

    @After
    public void tearDown() {
        booking = null;
    }

    /**
     * A simple method designed to change the total price of the booking when
     * the user has selected a flight, the number of tickets and luggage weight.
     */
    
    @Test
    public void testChangeTotalPrice0() {
        System.out.println("changeTotalPrice0");
        assertEquals((booking.getFlightPrice() * booking.getNoOfTickets()) + (500 * booking.getLuggageWeight()),
                Booking_controller.changeTotalPrice(booking), 0.1);
    }

    @Test
    public void testChangeTotalPrice1() {
        System.out.println("changeTotalPrice1");
        //Now let's change the parameters of the method.
        booking.setFlightPrice(1);
        booking.setNoOfTickets(1);
        booking.setLuggageWeight(0);
        assertEquals((booking.getFlightPrice() * booking.getNoOfTickets()) + (500 * booking.getLuggageWeight()),
                Booking_controller.changeTotalPrice(booking), 0.1);
    }

    @Test
    public void testChangeTotalPrice2() {
        System.out.println("changeTotalPrice2");
        //Changing the parameters again.
        booking.setFlightPrice(999999);
        booking.setNoOfTickets(300);
        booking.setLuggageWeight(60);
        assertEquals((booking.getFlightPrice() * booking.getNoOfTickets()) + (500 * booking.getLuggageWeight()),
                Booking_controller.changeTotalPrice(booking), 0.1);
    }
    @Test
    public void testChangeTotalPrice3() {
        System.out.println("changeTotalPrice3");
        //Changing the parameters again.
        booking.setFlightPrice(0);
        booking.setNoOfTickets(0);
        booking.setLuggageWeight(0);
        assertEquals((booking.getFlightPrice() * booking.getNoOfTickets()) + (500 * booking.getLuggageWeight()),
                Booking_controller.changeTotalPrice(booking), 0.1);
    }

    /**
     * This is a method used to convert different currencies that users might
     * use to pay for their booking. The user selects the currency through a
     * combobox, so it is not possible to select a currency that the method 
     * doesn't recognize. We decided to use the following tests to make sure
     * that the currencies converted in a correct manner, i.e. that the method
     * would return the right value each time. We used a currency converter
     * from Landsbankinn to hardcode the exchange rate of the currencies 
     * according to the exchange rates that Landsbankinn provided on April 2nd,
     * so "expected results" are built on calculations on those values.
     * In these tests we tried many different values, including some unlikely
     * ones, to make sure the method behaved the way it should.
     */
    @Test
    public void testChangeCurrency0() {
        System.out.println("changeCurrency0");
        String cur = "USD";
        booking.setPreviousCurrency("ISK");
        booking.setTotalPrice(10);
        assertEquals((booking.getTotalPrice() / 112.73), Booking_controller.changeCurrency(cur, booking), 0.1);
    }
    @Test
    public void testChangeCurrency1() {
        System.out.println("changeCurrency1");
        String cur = "NOK";
        booking.setTotalPrice(0);
        booking.setPreviousCurrency("EUR");
        assertEquals(((booking.getTotalPrice() / 13.13) * 120.54), Booking_controller.changeCurrency(cur, booking), 0.1);
    }
    @Test
    public void testChangeCurrency2() {
        System.out.println("changeCurrency2");
        String cur = "JPY";
        booking.setPreviousCurrency("GBP");
        booking.setTotalPrice(99999999);
        assertEquals(((booking.getTotalPrice() / 1.01) * 141.17), Booking_controller.changeCurrency(cur, booking), 0.1);
    }
    @Test
    public void testChangeCurrency3() {
        System.out.println("changeCurrency2");
        String cur = "ISK";
        booking.setPreviousCurrency("ISK");
        booking.setTotalPrice(999);
        assertEquals(((booking.getTotalPrice() / 1.0) * 1.0), Booking_controller.changeCurrency(cur, booking), 0.1);
    }

    /**
     * This method is kind of a support method for changeCurrency. Since we use
     * ISK as a base currency, we felt that it worked well to have a method
     * specifically designed to convert all available currencies to ISK before
     * they were to be converted to another type of currency.
     * In these tests we again tried many different values, including some 
     * unlikely ones, to make sure the method behaved the way it should.
     */
    
    @Test
    public void testChangeCurToISK0() {
        System.out.println("changeCurToISK0");
        String cur = "GBP";
        double currentTotal = 9999999;
        assertEquals((currentTotal * 141.17), Booking_controller.changeCurToISK(cur, currentTotal), 0.1);
    }

    @Test
    public void testChangeCurToISK1() {
        System.out.println("changeCurToISK1");
        String cur = "DKK";
        double currentTotal = 10;
        assertEquals((currentTotal * 16.21), Booking_controller.changeCurToISK(cur, currentTotal), 0.1);
    }

    @Test
    public void testChangeCurToISK2() {
        System.out.println("changeCurToISK2");
        String cur = "CHF";
        double currentTotal = 0.5;
        assertEquals((currentTotal * 112.69), Booking_controller.changeCurToISK(cur, currentTotal), 0.1);
    }
    @Test
    public void testChangeCurToISK3() {
        System.out.println("changeCurToISK2");
        String cur = "SEK";
        double currentTotal = 0.0;
        assertEquals((currentTotal * 12.61), Booking_controller.changeCurToISK(cur, currentTotal), 0.1);
    }

}

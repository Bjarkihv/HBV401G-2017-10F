/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FSE.model;

/**
 *
 * @author Notandi
 */
public class flightSearch {
    public String airline;
    public String departureTime;
    public String arrivalTime;
    public String departureLocation;
    public String arrivalLocation;
    public Boolean direct;
    public int minPrice;
    public int maxPrice;
    
    public flightSearch(String airl, String dt, String at, String dl, String al, Boolean dir, int minP, int maxP) {
        airline = airl;
        departureTime = dt;
        arrivalTime = at;
        departureLocation = dl;
        arrivalLocation = al;
        direct = dir;
        minPrice = minP;
        maxPrice = maxP;
    } 
    
     public void printInfo() {
      //System.out.println("Flight number: " + flightNo);
        System.out.println("From: " + departureLocation);
        System.out.println("To: " + arrivalLocation);
        System.out.println("Departure date: " + departureTime);
        if(!arrivalTime.equals("NULL")) System.out.println("Return date: " + arrivalTime);
        System.out.println("Direct: " + direct);
      //System.out.println("Seats available: " + seatsAvailable);
        System.out.println("Airline: " + airline);
      //System.out.println("Plane: " + plane);
        
    }

    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public String getDepartureLocation() {
        return departureLocation;
    }

    public void setDepartureLocation(String departureLocation) {
        this.departureLocation = departureLocation;
    }

    public String getArrivalLocation() {
        return arrivalLocation;
    }

    public void setArrivalLocation(String arrivalLocation) {
        this.arrivalLocation = arrivalLocation;
    }

    public Boolean getDirect() {
        return direct;
    }

    public void setDirect(Boolean direct) {
        this.direct = direct;
    }

    public int getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(int minPrice) {
        this.minPrice = minPrice;
    }

    public int getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(int maxPrice) {
        this.maxPrice = maxPrice;
    }
}


package FSE.model;


public class Account {
    
}
